//
//  CalculatorTests.swift
//  CalculatorTests
//
//  Created by Кирилл Кузнецов on 18.01.2021.
//  Copyright © 2021 kuznetsov. All rights reserved.
//

import XCTest
@testable import Calculator

class CalculatorTests: XCTestCase {
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func testCalc() {
        
    }

}
